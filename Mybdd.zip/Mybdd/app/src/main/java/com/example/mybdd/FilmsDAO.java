package com.example.mybdd;


import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.database.Cursor;


@Dao
public interface FilmsDAO {

    @Insert
    public void insertFilms(Films Film);

    @Insert
    public void insertPays(Pays Country);

    @Query("select * FROM Film")
    public Cursor getALLFilms();

    @Query("select * FROM Country where nameFilm= :nomFilm ")
    public Pays getPays(String nomFilm);


}
