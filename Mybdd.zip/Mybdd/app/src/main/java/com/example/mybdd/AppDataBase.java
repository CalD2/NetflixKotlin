package com.example.mybdd;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

@Database(entities = {Films.class, Pays.class}, version = 1)
public abstract class AppDataBase extends RoomDatabase
{
    private static AppDataBase INSTANCE;

    public abstract FilmsDAO filmDAO();

    public abstract FilmsDAO countryDAO();

}
